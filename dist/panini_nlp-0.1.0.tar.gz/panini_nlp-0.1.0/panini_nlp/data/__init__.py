# Data files bundled with panini-nlp
